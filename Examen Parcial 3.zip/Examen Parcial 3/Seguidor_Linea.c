; ----------------------------
; SEGUIDOR DE L�NEA - PIC16F84A
; ----------------------------
 
    LIST P=16F84A
    INCLUDE <P16F84A.INC>
 
; ----------------------------
; DEFINICIONES
SENSOR_ESTADO  EQU  0x20    ; Registro para guardar el estado de los sensores
 
; ----------------------------
    ORG     0x00
    GOTO    INICIO
 
; ----------------------------
; RUTINA PRINCIPAL
INICIO:
    ; Configuraci�n de puertos
    BSF     STATUS, RP0     ; Cambiar a banco 1
    MOVLW   B'11111110'     ; RA0 como entrada (1), resto salida
    MOVWF   TRISA
    MOVLW   B'11111110'     ; RB0 como entrada (1), resto salida
    MOVWF   TRISB
    BCF     STATUS, RP0     ; Banco 0
 
; Limpia puertos
    CLRF    PORTA
    CLRF    PORTB
 
BUCLE:
    CALL    LEER_SENSORES
    MOVF    SENSOR_ESTADO, W
    CALL    SALTO_INDEXADO
    GOTO    BUCLE
 
; ----------------------------
; LECTURA DE SENSORES
LEER_SENSORES:
    CLRF    SENSOR_ESTADO
 
    ; Sensor izquierdo en RB0 (bit 0)
    BTFSS   PORTB, 0        ; Si RB0 == 1 (no l�nea)
    BSF     SENSOR_ESTADO, 0 ; Si detecta l�nea, setea bit 0
 
    ; Sensor derecho en RA0 (bit 0)
    BTFSS   PORTA, 0        ; Si RA0 == 1 (no l�nea)
    BSF     SENSOR_ESTADO, 1 ; Si detecta l�nea, setea bit 1
 
    RETURN
 
; ----------------------------
; SALTO INDEXADO SEG�N SENSOR_ESTADO
SALTO_INDEXADO:
    ADDWF   PCL, f
 
; Tabla: (Bit1 = Der, Bit0 = Izq)
; 00 ? Ninguno detecta l�nea = detener
; 01 ? Solo Izq detecta l�nea = girar izquierda
; 10 ? Solo Der detecta l�nea = girar derecha
; 11 ? Ambos detectan l�nea = avanzar
 
    GOTO    DETENER         ; 00
    GOTO    GIRO_IZQUIERDA  ; 01
    GOTO    GIRO_DERECHA    ; 10
    GOTO    AVANZAR         ; 11
 
; ----------------------------
; ACCIONES DE MOTOR (PUENTE H)
 
AVANZAR:
    ; Ambos motores adelante
    BSF     PORTB, 1        ; Motor izquierdo adelante
    BSF     PORTB, 2        ; Motor derecho adelante
    RETURN
 
GIRO_IZQUIERDA:
    BSF     PORTB, 1        ; Motor izquierdo adelante
    BCF     PORTB, 2        ; Motor derecho apagado
    RETURN
 
GIRO_DERECHA:
    BCF     PORTB, 1        ; Motor izquierdo apagado
    BSF     PORTB, 2        ; Motor derecho adelante
    RETURN
 
DETENER:
    BCF     PORTB, 1        ; Apagar ambos motores
    BCF     PORTB, 2
    RETURN
 
; ----------------------------
    END